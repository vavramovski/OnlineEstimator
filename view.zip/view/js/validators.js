/**
 * Attach {validateHighLow} handler to elements with name in the array
 * */
window.addEventListener('load', function () {
    ['price', 'livingarea', 'landarea']
        .forEach(name => document.getElementsByName(name)
            .forEach(element => element.addEventListener('change', validateHighLow), false))
}, false)

/**
 * Data variable used for download button
 * */
let tableData = [];

// preventDefault()
$("form").submit(function (e) {
    return false;
});

function validateHighLow(e) {
    const [low, high] = document.getElementsByName(e.target.name)
    if (high.value === '' || low.value === '') {
        return;
    }
    isValid(low, high)
}

function isValid(low, high) {
    if (high.value === '' || low.value === '') {
        return true;
    }
    const lowValue = parseInt(low.value)
    const highValue = parseInt(high.value)
    if (highValue < lowValue || lowValue > highValue) {
        low.classList.remove('valid')
        high.classList.remove('valid')
        low.classList.add('invalid')
        high.classList.add('invalid')
        return false;
    } else {
        low.classList.remove('invalid')
        high.classList.remove('invalid')
        low.classList.add('valid')
        high.classList.add('valid')
        return true;
    }
}

function addInvalidClass(element, isInvalid) {
    if (isInvalid) {
        element.classList.remove('valid')
        element.classList.add('invalid')
    } else {
        element.classList.remove('invalid')
        element.classList.add('valid')
    }
}

/**
 * Check if Select fields have selected values
 * if not -> red warning
 * */
function validateSelectFields() {
    const zip = document.getElementById('postcode');
    const zipInput = document.getElementById('postcode').parentNode.children[0];

    const address = document.getElementById('address');
    const addressInput = document.getElementById('address').parentNode.children[0];

    const type = document.getElementById('type');
    const typeInput = document.getElementById('type').parentNode.children[0];

    let flag = true;
    const fields = [[zip, zipInput], [address, addressInput], [type, typeInput]];

    fields.forEach(([field, inputField]) => {
        if (field.value === '') {
            console.log('invalid')
            addInvalidClass(inputField, true);
            flag = false;
        } else {
            console.log('valid')
            addInvalidClass(inputField, false);
        }
    })

    return flag;
}


function setData(data){
    tableData = data;
}

/**
 * Gather data, and GET search results
 * */
function handleSearch() {
    /** Global variables {startDate} and {endDate}*/
    const [minPrice, maxPrice] = document.getElementsByName('price')
    const zip = document.getElementById('postcode').value;
    const address = document.getElementById('address').value;
    const type = document.getElementById('type').value;
    const [minLivingArea, maxLivingArea] = document.getElementsByName('livingarea');
    const [minLandArea, maxLandArea] = document.getElementsByName('landarea');

    //if at least one of them is invalid, return
    const isValidPrice = !isValid(minPrice, maxPrice);
    const isValidLivingArea = !isValid(minLivingArea, maxLivingArea);
    const isValidLandArea = !isValid(minLandArea, maxLandArea);
    const isValidMinLandLiving = !isValid(minLivingArea, minLandArea);
    const isValidMaxLandLiving = !isValid(maxLivingArea, maxLandArea);
    const isValidSelectFields = !validateSelectFields();
    if (isValidPrice || isValidLivingArea || isValidLandArea ||
        isValidMinLandLiving || isValidMaxLandLiving ||
        isValidSelectFields) {
        return;
    }

    const url = new URL('http://localhost:3000/search')
    if (minPrice.value >= maxPrice.value) {

    }
    const params = {
        dateFrom: startDate,
        dateTo: endDate,
        minPrice: minPrice.value,
        maxPrice: maxPrice.value,
        zip,
        address,
        type,
        minLivingArea: minLivingArea.value,
        maxLivingArea: maxLivingArea.value,
        minLandArea: minLandArea.value,
        maxLandArea: maxLandArea.value,
    }
    url.search = new URLSearchParams(params).toString();

    fetch(url)
        .then(resp => resp.json())
        .then(data => {
            setData(data);
            renderPagination(data)
        })
        .catch(console.log);
}